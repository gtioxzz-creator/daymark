DAYMARK — complete source
==========================

This zip is the whole app: Today, Week, Tasks, Journal, Habits, Ledger,
Ask Daymark, calendar drag/resize, account save, and the darkwood UI.

To run it somewhere else:
1. Unzip
2. npm install
3. npm run dev
   (this project expects the TanStack Start / Vite setup on port 8080)

Your personal day on the phone is NOT in this zip. That lives in the
browser and on your signed-in account. This file is the program.

Come back here and we keep building.
